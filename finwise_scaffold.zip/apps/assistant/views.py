import json
import requests
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from . import tools

GEMINI_ENDPOINT = "https://api.gemini.example/v1/chat"  # placeholder

class AssistantQueryView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        user_query = request.data.get('query')
        tool_specs = [
            {"name": "get_user_portfolio", "description": "Returns the user's portfolio as JSON", "parameters": {}},
            {"name": "get_stock_metrics", "description": "Returns metrics for a given ticker", "parameters": {"ticker": {"type": "string"}}}
        ]
        payload = {
            "model": "gemini-1",
            "input": user_query,
            "functions": tool_specs,
            "max_tokens": 512,
            "api_key": settings.GEMINI_API_KEY
        }
        r = requests.post(GEMINI_ENDPOINT, json=payload, timeout=15)
        r.raise_for_status()
        llm_response = r.json()
        tool_call = llm_response.get("tool_call")
        if not tool_call:
            return Response({"reply": llm_response.get("text")})
        tool_name = tool_call.get("tool_name")
        args = tool_call.get("arguments", {})
        if tool_name == "get_user_portfolio":
            data = tools.get_user_portfolio(user)
        elif tool_name == "get_stock_metrics":
            ticker = args.get("ticker")
            data = tools.get_stock_metrics(ticker)
        else:
            return Response({"error": "unknown tool"}, status=400)
        followup_payload = {
            "model": "gemini-1",
            "input": f"User query: {user_query}\nTool response: {json.dumps(data, default=str)}\nPlease provide an actionable guidance.",
            "api_key": settings.GEMINI_API_KEY
        }
        r2 = requests.post(GEMINI_ENDPOINT, json=followup_payload, timeout=15)
        r2.raise_for_status()
        final = r2.json()
        assistant_text = final.get("text", "")
        tools.record_conversation(user, user_query, assistant_text)
        return Response({"reply": assistant_text, "tool_data": data})
