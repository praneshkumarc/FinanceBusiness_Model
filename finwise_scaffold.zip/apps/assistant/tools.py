from apps.markets import services
from .models import ConversationLog

def get_user_portfolio(user):
    from apps.portfolios.models import Portfolio
    return list(Portfolio.objects.filter(owner=user).values())

def get_stock_metrics(ticker):
    return services.fetch_quote(ticker), services.fetch_company_profile(ticker), services.fetch_key_metrics(ticker)

def record_conversation(user, prompt, response, metadata=None):
    ConversationLog.objects.create(user=user, prompt=prompt, response=response)
