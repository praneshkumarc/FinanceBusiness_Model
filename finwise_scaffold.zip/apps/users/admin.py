from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import FinWiseUser

@admin.register(FinWiseUser)
class FinWiseUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('FinWise Fields', {'fields': ('phone_number','risk_tolerance','investment_horizon','financial_goals')}),
    )
