from django.db import models
from django.contrib.auth.models import AbstractUser

class FinWiseUser(AbstractUser):
    phone_number = models.CharField(max_length=17, blank=True)
    RISK_CHOICES = [(i,str(i)) for i in range(1,6)]
    risk_tolerance = models.IntegerField(choices=RISK_CHOICES, null=True, blank=True)
    HORIZON_CHOICES = [('short','Short-term'),('long','Long-term')]
    investment_horizon = models.CharField(max_length=20, choices=HORIZON_CHOICES, null=True, blank=True)
    financial_goals = models.TextField(blank=True)
