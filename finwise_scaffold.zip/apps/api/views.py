from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from apps.markets import services

class StockMetricsView(APIView):
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request, ticker):
        ticker = ticker.upper()
        quote = services.fetch_quote(ticker)
        profile = services.fetch_company_profile(ticker)
        metrics = services.fetch_key_metrics(ticker)
        response = {
            "ticker": ticker,
            "quote": quote,
            "profile": profile,
            "metrics": metrics.get("metric", metrics)
        }
        return Response(response)
