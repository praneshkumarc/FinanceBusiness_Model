from django.urls import path
from apps.api.views import StockMetricsView
from apps.assistant.views import AssistantQueryView

urlpatterns = [
    path('markets/stocks/<str:ticker>/', StockMetricsView.as_view(), name='stock-metrics'),
    path('assistant/query/', AssistantQueryView.as_view(), name='assistant-query'),
]
