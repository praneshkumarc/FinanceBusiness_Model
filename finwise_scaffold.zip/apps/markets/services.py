import requests
from django.conf import settings

FINNHUB_BASE = "https://finnhub.io/api/v1"

def fetch_quote(ticker: str):
    url = f"{FINNHUB_BASE}/quote"
    params = {"symbol": ticker, "token": settings.FINNHUB_API_KEY}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json()

def fetch_company_profile(ticker: str):
    url = f"{FINNHUB_BASE}/stock/profile2"
    params = {"symbol": ticker, "token": settings.FINNHUB_API_KEY}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json()

def fetch_key_metrics(ticker: str):
    url = f"{FINNHUB_BASE}/stock/metric"
    params = {"symbol": ticker, "metric": "all", "token": settings.FINNHUB_API_KEY}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json()
