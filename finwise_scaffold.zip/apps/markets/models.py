from django.db import models

class Stock(models.Model):
    ticker = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=200, blank=True)

class MarketDataPoint(models.Model):
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    timestamp = models.DateTimeField()
    open = models.FloatField(null=True)
    high = models.FloatField(null=True)
    low = models.FloatField(null=True)
    close = models.FloatField(null=True)
    volume = models.BigIntegerField(null=True)
