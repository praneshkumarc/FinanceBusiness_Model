import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' }
});

export async function getStockMetrics(ticker) {
  const res = await api.get(`/markets/stocks/${ticker}/`);
  return res.data;
}

export async function assistantQuery(query) {
  const res = await api.post('/assistant/query/', { query });
  return res.data;
}
