import React from 'react';
import StockCompare from './components/StockCompare';
import SIPCalculator from './components/SIPCalculator';
import TaxCalculator from './components/TaxCalculator';
import AssistantChat from './components/AssistantChat';

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4">
        <div className="container mx-auto flex justify-between">
          <h1 className="text-xl font-bold">FinWise</h1>
          <nav className="space-x-4">
            <a>Dashboard</a>
            <a>Markets</a>
            <a>Assistant</a>
          </nav>
        </div>
      </header>
      <main className="container mx-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <StockCompare />
        </div>
        <aside className="space-y-4">
          <SIPCalculator />
          <TaxCalculator />
        </aside>
        <section className="md:col-span-3">
          <AssistantChat />
        </section>
      </main>
    </div>
  );
}
