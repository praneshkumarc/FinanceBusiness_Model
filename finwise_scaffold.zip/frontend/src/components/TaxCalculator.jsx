import React, { useState } from 'react';

function calculateTax(annualIncome){
  let tax = 0;
  let remaining = annualIncome;
  const slabs = [
    {limit: 250000, rate: 0},
    {limit: 500000, rate: 0.05},
    {limit: 1000000, rate: 0.2},
    {limit: Infinity, rate: 0.3}
  ];
  let prev = 0;
  for(const s of slabs){
    const slabAmount = Math.min(remaining, s.limit - prev);
    if(slabAmount > 0){
      tax += slabAmount * s.rate;
      remaining -= slabAmount;
      prev = s.limit;
    }
    if(remaining <= 0) break;
  }
  tax = tax * 1.04;
  return Math.round(tax);
}

export default function TaxCalculator(){
  const [income, setIncome] = useState(750000);
  const tax = calculateTax(income);

  return (
    <div className="p-4 border rounded">
      <h3 className="text-lg font-semibold">Indian Tax Calculator (Est.)</h3>
      <label className="block mt-2">Annual Income (₹)
        <input type="number" value={income} onChange={e=>setIncome(+e.target.value)} className="w-full border p-2 rounded"/>
      </label>
      <div className="mt-2"><strong>Estimated Tax:</strong> ₹ {tax.toLocaleString('en-IN')}</div>
      <small className="text-gray-500">This is an estimate. Use actual tax slabs and exemptions for production.</small>
    </div>
  );
}
