import React, { useState } from 'react';
import { assistantQuery } from '../api/client';

export default function AssistantChat(){
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState([]);

  async function send(){
    if(!query.trim()) return;
    const userMsg = {role: 'user', text: query};
    setMessages([...messages, userMsg]);
    setQuery('');
    const res = await assistantQuery(query);
    const reply = {role:'assistant', text: res.reply || res.error || JSON.stringify(res)};
    setMessages(prev => [...prev, reply]);
  }

  return (
    <div className="p-4 border rounded">
      <h3 className="text-lg font-semibold">FinWise Assistant</h3>
      <div className="mt-3 space-y-2 max-h-64 overflow-auto">
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : 'text-left'}>
            <div className={`inline-block p-2 rounded ${m.role==='user' ? 'bg-slate-800 text-white' : 'bg-slate-100'}`}>{m.text}</div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <input value={query} onChange={e=>setQuery(e.target.value)} className="flex-1 border p-2 rounded"/>
        <button onClick={send} className="btn-primary">Ask</button>
      </div>
    </div>
  );
}
