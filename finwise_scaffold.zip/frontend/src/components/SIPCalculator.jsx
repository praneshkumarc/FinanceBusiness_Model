import React, { useState } from 'react';

function futureValue(monthly, rAnnual, years) {
  const r = rAnnual / 12 / 100;
  const n = years * 12;
  return monthly * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
}

export default function SIPCalculator(){
  const [monthly, setMonthly] = useState(5000);
  const [r, setR] = useState(12);
  const [years, setYears] = useState(10);
  const fv = Math.round(futureValue(monthly, r, years));

  return (
    <div className="p-4 border rounded">
      <h3 className="text-lg font-semibold">SIP Calculator</h3>
      <div className="grid grid-cols-1 gap-2 mt-3">
        <label>Monthly Investment (₹)
          <input type="number" value={monthly} onChange={e=>setMonthly(+e.target.value)} className="w-full border p-2 rounded"/>
        </label>
        <label>Expected Annual Return (%) 
          <input type="number" value={r} onChange={e=>setR(+e.target.value)} className="w-full border p-2 rounded"/>
        </label>
        <label>Tenure (years)
          <input type="number" value={years} onChange={e=>setYears(+e.target.value)} className="w-full border p-2 rounded"/>
        </label>
        <div className="mt-2">
          <strong>Estimated Corpus:</strong> ₹ {fv.toLocaleString('en-IN')}
        </div>
      </div>
    </div>
  );
}
