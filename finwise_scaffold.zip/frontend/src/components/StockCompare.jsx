import React, { useState } from 'react';
import { getStockMetrics } from '../api/client';

export default function StockCompare(){
  const [tickers, setTickers] = useState(['AAPL','MSFT']);
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(false);

  async function fetchAll(){
    setLoading(true);
    const resObj = {};
    for(const t of tickers){
      try{
        const d = await getStockMetrics(t);
        resObj[t] = d;
      } catch(e){
        resObj[t] = { error: e.message };
      }
    }
    setData(resObj);
    setLoading(false);
  }

  function updateTicker(idx, val){
    const arr = [...tickers];
    arr[idx] = val.toUpperCase();
    setTickers(arr);
  }

  function addTicker(){ setTickers([...tickers, '']); }

  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-3">Compare Stocks</h2>
      <div className="flex gap-2 flex-wrap">
        {tickers.map((t, i) => (
          <input key={i}
            value={t}
            onChange={e => updateTicker(i, e.target.value)}
            className="border p-2 rounded w-36"
            placeholder="Ticker"/>
        ))}
        <button onClick={addTicker} className="btn">+ Add</button>
        <button onClick={fetchAll} disabled={loading} className="btn-primary">{loading ? 'Loading…' : 'Compare'}</button>
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(data).map(([t, d]) => (
          <div key={t} className="border rounded p-3 shadow">
            <h3 className="font-medium">{t}</h3>
            {d.error ? <p className="text-red-500">Error: {d.error}</p> :
              <>
                <p>Price: {d.quote?.c ?? '—'}</p>
                <p>Open: {d.quote?.o ?? '—'}</p>
                <p>Market Cap: {d.profile?.marketCapitalization ?? '—'}</p>
                <p>PE Ratio: {d.metrics?.peBasicExclExtraTTM ?? '—'}</p>
                <p>EBITDA: {d.metrics?.ebitda ?? '—'}</p>
              </>
            }
          </div>
        ))}
      </div>
    </div>
  );
}
